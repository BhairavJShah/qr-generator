import { User, Event, Participation, MatchProfile, Carpool, Notification } from '../types';

export const currentUser: User = {
  id: 'u1',
  name: 'Alex Chen',
  college: 'State University',
  role: 'Student',
  gradYear: 2027,
  techStack: ['React Native', 'TypeScript', 'Node.js'],
  avatarUrl: 'https://picsum.photos/seed/alex/150/150',
};

export const alumniUser: User = {
  id: 'u2',
  name: 'Sarah Jenkins',
  college: 'Tech Institute',
  role: 'Alumni',
  gradYear: 2024,
  techStack: ['Python', 'Machine Learning', 'AWS'],
  avatarUrl: 'https://picsum.photos/seed/sarah/150/150',
};

export const mockEvents: Event[] = [
  {
    id: 'e1',
    title: 'HackTheFuture 2026',
    eventType: 'Hackathon',
    hostId: 'u1',
    hostCollege: 'Tech Institute',
    organization: 'Tech Institute Innovation Lab',
    logoUrl: 'https://picsum.photos/seed/org1/150/150',
    date: '2026-04-15T09:00:00Z',
    endDate: '2026-04-17T18:00:00Z',
    location: 'Tech Institute Main Campus',
    mode: 'Offline',
    teamSize: '1-4 members',
    participationType: 'Competition',
    eligibleYears: ['1st Year', '2nd Year', '3rd Year', '4th Year'],
    gender: 'Any',
    registrationCriteria: 'Must be currently enrolled in a university program.',
    registrationLink: 'https://forms.gle/example1',
    description: 'A 48-hour hackathon focused on AI and sustainability. Open to all university students.',
    tags: ['Hackathon', 'AI', 'Sustainability'],
    imageUrl: 'https://picsum.photos/seed/hackathon/600/300',
    isExpired: false,
    rewards: '$5000 Prize Pool + Internships + AWS Credits',
    whoCanRegister: 'All University Students',
    organizerContacts: [
      { name: 'Alex Chen', role: 'Lead Organizer', phone: '+1234567890', email: 'alex@example.com' }
    ],
    faqs: [
      { question: 'Do I need to have a team?', answer: 'You can participate solo or in a team of up to 4 members.' },
      { question: 'Is it free to register?', answer: 'Yes, registration is completely free for all university students.' }
    ]
  },
  {
    id: 'e4',
    title: 'Vibrance 2026',
    eventType: 'College Festival',
    hostId: 'u2',
    hostCollege: 'State University',
    organization: 'Student Council',
    logoUrl: 'https://picsum.photos/seed/vibrance_logo/150/150',
    date: '2026-05-10T09:00:00Z',
    endDate: '2026-05-12T23:00:00Z',
    location: 'State University Campus',
    mode: 'Offline',
    description: 'The biggest annual cultural and technical festival of State University.',
    tags: ['Festival', 'Cultural', 'Technical'],
    imageUrl: 'https://picsum.photos/seed/vibrance/600/300',
    photos: [
      'https://picsum.photos/seed/vibrance1/600/300',
      'https://picsum.photos/seed/vibrance2/600/300',
      'https://picsum.photos/seed/vibrance3/600/300'
    ],
    isExpired: false,
    rewards: 'Trophies, 100% Scholarships, and Cash Prizes worth $10,000',
    whoCanRegister: 'Open to all college students across the country',
    campaignName: '#VibeWithVibrance',
    campaignLink: 'https://instagram.com/vibrance_fest',
    organizerContacts: [
      { name: 'Sarah Jenkins', role: 'Fest Coordinator', phone: '+1987654321', email: 'sarah@example.com' },
      { name: 'John Doe', role: 'Cultural Head', phone: '+1122334455', email: 'john@example.com' }
    ],
    faqs: [
      { question: 'Is accommodation provided?', answer: 'Yes, accommodation is provided for outstation participants upon prior request.' },
      { question: 'Can I participate in multiple sub-events?', answer: 'Yes, as long as the timings do not clash.' }
    ],
    subEvents: [
      {
        id: 'e4-1',
        title: 'Battle of Bands',
        eventType: 'Cultural Event',
        hostId: 'u2',
        hostCollege: 'State University',
        date: '2026-05-10T18:00:00Z',
        endDate: '2026-05-10T22:00:00Z',
        location: 'Main Auditorium',
        description: 'Rock the stage with your band.',
        tags: ['Music', 'Band'],
        imageUrl: 'https://picsum.photos/seed/band/600/300',
        rewards: '$1000 First Prize',
        whoCanRegister: 'Bands of 3-6 members'
      },
      {
        id: 'e4-2',
        title: 'Tech Quiz',
        eventType: 'Quiz',
        hostId: 'u2',
        hostCollege: 'State University',
        date: '2026-05-11T10:00:00Z',
        endDate: '2026-05-11T13:00:00Z',
        location: 'Seminar Hall A',
        description: 'Test your knowledge in technology and current affairs.',
        tags: ['Quiz', 'Tech'],
        imageUrl: 'https://picsum.photos/seed/quiz/600/300',
        rewards: '$200 First Prize',
        whoCanRegister: 'Individual or Team of 2'
      }
    ]
  },
  {
    id: 'e2',
    title: 'Design Thinking Workshop',
    eventType: 'Conference',
    hostId: 'u2',
    hostCollege: 'Liberal Arts College',
    organization: 'Design Student Association',
    logoUrl: 'https://picsum.photos/seed/org2/150/150',
    date: '2026-03-28T14:00:00Z',
    endDate: '2026-03-28T17:00:00Z',
    location: 'LAC Design Center',
    mode: 'Offline',
    teamSize: 'Individual',
    participationType: 'Workshop',
    eligibleYears: ['1st Year', '2nd Year'],
    gender: 'Any',
    registrationCriteria: 'Open to beginners with an interest in UI/UX.',
    registrationLink: 'https://forms.gle/example2',
    description: 'Learn the fundamentals of UI/UX and design thinking from industry experts.',
    tags: ['Workshop', 'Design', 'UI/UX'],
    imageUrl: 'https://picsum.photos/seed/design/600/300',
    isExpired: false,
  },
  {
    id: 'e3',
    title: 'Spring Code Jam (Expired)',
    hostId: 'u2',
    hostCollege: 'State University',
    organization: 'Computer Science Club',
    logoUrl: 'https://picsum.photos/seed/org3/150/150',
    date: '2026-03-20T10:00:00Z',
    endDate: '2026-03-21T20:00:00Z',
    location: 'State Uni Library',
    mode: 'Online',
    teamSize: '1-3 members',
    participationType: 'Competition',
    eligibleYears: ['3rd Year', '4th Year'],
    gender: 'Any',
    registrationCriteria: 'Must have basic knowledge of algorithms.',
    registrationLink: 'https://forms.gle/example3',
    description: 'Our annual spring coding competition. (This event is in its 48-hour retention window before deletion).',
    tags: ['Competition', 'Algorithms'],
    imageUrl: 'https://picsum.photos/seed/codejam/600/300',
    isExpired: true,
  },
];

export const mockParticipations: Participation[] = [
  {
    id: 'p1',
    eventId: 'e10',
    eventTitle: 'Winter Web Summit',
    role: 'Winner',
    verified: true,
    date: '2025-12-10',
  },
  {
    id: 'p2',
    eventId: 'e11',
    eventTitle: 'Campus Cloud Conference',
    role: 'Organizer',
    verified: true,
    date: '2025-10-05',
  },
  {
    id: 'p3',
    eventId: 'e12',
    eventTitle: 'Intro to Rust Workshop',
    role: 'Attendee',
    verified: true,
    date: '2025-09-15',
  },
];

export const mockMatches: MatchProfile[] = [
  {
    id: 'm1',
    user: {
      id: 'u3',
      name: 'David Kim',
      college: 'Engineering College',
      role: 'Student',
      gradYear: 2026,
      techStack: ['Python', 'Django', 'PostgreSQL'],
      avatarUrl: 'https://picsum.photos/seed/david/150/150',
    },
    lookingFor: ['React', 'Frontend Design'],
    message: 'Looking for a frontend dev to build an AI study app for the hackathon!',
  },
  {
    id: 'm2',
    user: {
      id: 'u4',
      name: 'Priya Patel',
      college: 'Business School',
      role: 'Student',
      gradYear: 2025,
      techStack: ['Figma', 'Product Management'],
      avatarUrl: 'https://picsum.photos/seed/priya/150/150',
    },
    lookingFor: ['Fullstack Developer', 'Mobile'],
    message: 'I have a great pitch and designs ready. Need technical co-founders.',
  },
];

export const mockCarpools: Carpool[] = [
  {
    id: 'c1',
    driver: {
      id: 'u5',
      name: 'Marcus Johnson',
      college: 'State University',
      role: 'Student',
      gradYear: 2026,
      techStack: [],
      avatarUrl: 'https://picsum.photos/seed/marcus/150/150',
    },
    departureLocation: 'State Uni North Dorms',
    departureTime: 'April 15, 7:30 AM',
    availableSeats: 3,
    price: 'Split Gas (~$5)',
  },
  {
    id: 'c2',
    driver: alumniUser,
    departureLocation: 'Downtown Metro Station',
    departureTime: 'April 15, 8:00 AM',
    availableSeats: 2,
    price: 'Free (Alumni Mentor)',
  },
];

export const mockNotifications: Notification[] = [
  {
    id: 'n1',
    userId: 'u1',
    title: 'Event Updated',
    message: 'The location for "Design Thinking Workshop" has been changed to LAC Design Center - Room 404.',
    timestamp: new Date().toISOString(),
    read: false,
    type: 'event_update',
    eventId: 'e2'
  },
  {
    id: 'n2',
    userId: 'u1',
    title: 'New Connection Request',
    message: 'Sophia Martinez wants to connect with you.',
    timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 mins ago
    read: false,
    type: 'connection_request',
    senderId: 'u12',
    senderName: 'Sophia Martinez',
    senderAvatar: 'https://picsum.photos/seed/sophia/150/150'
  },
  {
    id: 'n3',
    userId: 'u1',
    title: 'Connection Accepted',
    message: 'Emma Watson accepted your connection request. You can now message her.',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
    read: true,
    type: 'general',
    senderId: 'u10',
    senderName: 'Emma Watson',
    senderAvatar: 'https://picsum.photos/seed/emma/150/150'
  },
  {
    id: 'n4',
    userId: 'u1',
    title: 'Event Reminder',
    message: 'HackTheFuture 2026 starts tomorrow at 9:00 AM!',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
    read: true,
    type: 'event_update',
    eventId: 'e1'
  }
];

export const mockNetworkUsers = [
  {
    id: 'u10',
    name: 'Emma Watson',
    avatarUrl: 'https://picsum.photos/seed/emma/150/150',
    college: 'Stanford University',
    department: 'Computer Science',
    gender: 'Female',
    yearOfStudy: '4th Year',
    techStack: ['React', 'Node.js', 'TypeScript'],
    gradYear: 2025,
    connectionStatus: 'connected'
  },
  {
    id: 'u11',
    name: 'Liam Chen',
    avatarUrl: 'https://picsum.photos/seed/liam/150/150',
    college: 'MIT',
    department: 'Data Science',
    gender: 'Male',
    yearOfStudy: '3rd Year',
    techStack: ['Python', 'Machine Learning', 'PyTorch'],
    gradYear: 2024,
    connectionStatus: 'none'
  },
  {
    id: 'u12',
    name: 'Sophia Martinez',
    avatarUrl: 'https://picsum.photos/seed/sophia/150/150',
    college: 'UC Berkeley',
    department: 'Design',
    gender: 'Female',
    yearOfStudy: '2nd Year',
    techStack: ['UI/UX', 'Figma', 'CSS'],
    gradYear: 2026,
    connectionStatus: 'pending'
  },
  {
    id: 'u13',
    name: 'Noah Kim',
    avatarUrl: 'https://picsum.photos/seed/noah/150/150',
    college: 'State University',
    department: 'Software Engineering',
    gender: 'Male',
    yearOfStudy: '1st Year',
    techStack: ['Java', 'Spring Boot', 'AWS'],
    gradYear: 2025,
    connectionStatus: 'connected'
  }
];
