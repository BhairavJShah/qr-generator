/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { Bell, ArrowLeft } from 'lucide-react';
import BottomNav from './components/BottomNav';
import Home from './components/Home';
import EventDetail from './components/EventDetail';
import Portfolio from './components/Portfolio';
import NotificationsPanel from './components/NotificationsPanel';
import MainMenu from './components/MainMenu';
import Network from './components/Network';
import Chat from './components/Chat';
import OrganizerDashboard from './components/OrganizerDashboard';
import { mockEvents, mockNotifications, currentUser } from './data/mock';
import { Event } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'portfolio' | 'network' | 'organizer'>('home');
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState(mockNotifications);
  const [chatUser, setChatUser] = useState<any | null>(null);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-kootam-bg text-kootam-text font-sans selection:bg-kootam-action/30 selection:text-white transition-colors duration-200">
      {/* Mobile constraint container for desktop viewing */}
      <div className="md:max-w-md md:mx-auto bg-kootam-bg md:min-h-screen relative overflow-hidden">
        
        {/* Header - Glassmorphism, no borders */}
        <header className="px-6 pt-safe-6 pb-4 sticky top-0 z-30 bg-[rgba(255,255,255,0.04)] backdrop-blur-md">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              {activeTab === 'home' ? (
                <MainMenu onNavigate={(tab) => setActiveTab(tab as any)} />
              ) : (
                <button 
                  onClick={() => setActiveTab('home')}
                  className="p-2 -ml-2 rounded-full text-white hover:bg-white/10 transition-colors focus:outline-none"
                >
                  <ArrowLeft size={24} />
                </button>
              )}
              <h1 className="text-2xl font-display font-bold tracking-tight text-white">
                {activeTab === 'home' && 'KOOTAM'}
                {activeTab === 'portfolio' && 'My Profile'}
                {activeTab === 'network' && 'Connect'}
                {activeTab === 'organizer' && 'Organizer'}
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setShowNotifications(true)} 
                className="relative text-white hover:text-kootam-action transition-colors"
              >
                <Bell size={24} strokeWidth={2} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-kootam-action rounded-full"></span>
                )}
              </button>
              <button 
                onClick={() => setActiveTab('portfolio')}
                className="relative w-9 h-9 rounded-full overflow-hidden hover:ring-2 hover:ring-kootam-action transition-all focus:outline-none"
              >
                <img 
                  src={currentUser.avatarUrl} 
                  alt={currentUser.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="min-h-[calc(100vh-140px)] pb-24">
          {activeTab === 'home' && (
            <Home events={mockEvents} onEventClick={(e) => setSelectedEvent(e)} />
          )}

          {activeTab === 'portfolio' && <Portfolio />}
          {activeTab === 'network' && <Network onOpenChat={setChatUser} />}
          {activeTab === 'organizer' && <OrganizerDashboard />}
        </main>

        {/* Overlays */}
        <AnimatePresence>
          {selectedEvent && (
            <EventDetail 
              event={selectedEvent} 
              onBack={() => setSelectedEvent(null)} 
            />
          )}
          {showNotifications && (
            <NotificationsPanel 
              notifications={notifications} 
              onUpdateNotifications={setNotifications}
              onClose={() => setShowNotifications(false)} 
            />
          )}
          {chatUser && (
            <Chat user={chatUser} onBack={() => setChatUser(null)} />
          )}
        </AnimatePresence>

        {/* Bottom Navigation */}
        {(activeTab === 'home' || activeTab === 'network') && (
          <BottomNav activeTab={activeTab as 'home' | 'network'} onChange={setActiveTab} />
        )}
      </div>
    </div>
  );
}
