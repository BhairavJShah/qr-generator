export type Role = 'Student' | 'Alumni';
export type ParticipationRole = 'Attendee' | 'Organizer' | 'Mentor' | 'Judge' | 'Winner';

export interface User {
  id: string;
  name: string;
  college: string;
  role: Role;
  gradYear: number;
  techStack: string[];
  avatarUrl: string;
}

export type EventType = 'Hackathon' | 'Quiz' | 'Conference' | 'Cultural Event' | 'College Festival' | 'Other';

export interface OrganizerContact {
  name: string;
  role?: string;
  phone?: string;
  email?: string;
}

export interface FAQ {
  question: string;
  answer: string;
}

export interface Event {
  id: string;
  title: string;
  eventType?: EventType;
  hostId: string;
  hostCollege: string;
  organization?: string;
  logoUrl?: string;
  date: string;
  endDate: string; // For the 48-hour expiration logic
  location: string;
  mode?: 'Online' | 'Offline';
  teamSize?: string;
  participationType?: string;
  eligibleYears?: string[];
  gender?: string;
  registrationCriteria?: string;
  registrationLink?: string;
  description: string;
  tags: string[];
  imageUrl: string;
  photos?: string[];
  isExpired?: boolean;
  organizerContacts?: OrganizerContact[];
  rewards?: string;
  whoCanRegister?: string;
  campaignLink?: string;
  campaignName?: string;
  subEvents?: Event[];
  faqs?: FAQ[];
}

export interface Participation {
  id: string;
  eventId: string;
  eventTitle: string;
  role: ParticipationRole;
  verified: boolean;
  date: string;
}

export interface MatchProfile {
  id: string;
  user: User;
  lookingFor: string[];
  message: string;
}

export interface Carpool {
  id: string;
  driver: User;
  departureLocation: string;
  departureTime: string;
  availableSeats: number;
  price: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type?: 'event_update' | 'connection_request' | 'general';
  eventId?: string;
  senderId?: string;
  senderAvatar?: string;
  senderName?: string;
}
