import { currentUser, mockParticipations } from '../data/mock';
import { Award, CheckCircle, ShieldCheck, GraduationCap } from 'lucide-react';
import { motion } from 'motion/react';

export default function Portfolio() {
  return (
    <div className="pb-24 pt-6 px-4 transition-colors duration-200">
      <div className="text-center mb-10">
        <div className="relative inline-block">
          <img 
            src={currentUser.avatarUrl} 
            alt={currentUser.name} 
            className="w-28 h-28 rounded-full border-4 border-kootam-surface shadow-lg mx-auto mb-4 object-cover bg-kootam-bg p-1"
            referrerPolicy="no-referrer"
          />
          <div className="absolute bottom-2 right-0 bg-kootam-action text-white p-2 rounded-full border-4 border-kootam-bg shadow-sm">
            <ShieldCheck size={16} />
          </div>
        </div>
        <h2 className="text-3xl font-display font-bold text-white mb-1">{currentUser.name}</h2>
        <p className="text-kootam-muted font-medium">{currentUser.college} • Class of {currentUser.gradYear}</p>
        
        <div className="flex flex-wrap justify-center gap-2 mt-6">
          {currentUser.techStack.map(tech => (
            <span key={tech} className="bg-kootam-surface text-kootam-muted text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-full">
              {tech}
            </span>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-kootam-action to-red-900 rounded-3xl p-6 text-white shadow-lg mb-10 relative overflow-hidden">
        <div className="absolute top-0 right-0 opacity-10 transform translate-x-4 -translate-y-4">
          <Award size={140} />
        </div>
        <h3 className="text-xl font-display font-bold mb-2 relative z-10">Verified Portfolio</h3>
        <p className="text-white/80 text-sm mb-6 relative z-10 max-w-[85%] leading-relaxed">
          Cryptographically verified proof of participation for your resume.
        </p>
        <button className="bg-white text-kootam-action text-sm font-bold py-3 px-6 rounded-full shadow-sm hover:bg-gray-100 transition-colors relative z-10 active:scale-[0.98]">
          Share Public Link
        </button>
      </div>

      <div className="space-y-4">
        <h3 className="font-display font-bold text-white text-xl flex items-center gap-3 mb-6">
          <GraduationCap size={24} className="text-kootam-action" /> Event History
        </h3>
        
        {mockParticipations.map((p, index) => (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            key={p.id} 
            className="bg-kootam-surface rounded-3xl p-5 flex items-start gap-4"
          >
            <div className={`p-3.5 rounded-2xl flex-shrink-0 ${
              p.role === 'Winner' ? 'bg-yellow-500/10 text-yellow-500' :
              p.role === 'Organizer' ? 'bg-purple-500/10 text-purple-500' :
              'bg-blue-500/10 text-blue-500'
            }`}>
              <Award size={24} />
            </div>
            <div className="flex-1 pt-1">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-display font-bold text-white leading-tight text-lg">{p.eventTitle}</h4>
                {p.verified && (
                  <span className="flex items-center text-kootam-accent text-[10px] font-bold uppercase tracking-wider bg-kootam-accent/10 px-2 py-1 rounded-full">
                    <CheckCircle size={12} className="mr-1" /> Verified
                  </span>
                )}
              </div>
              <p className="text-sm font-medium text-kootam-muted mb-1">Role: {p.role}</p>
              <p className="text-xs text-kootam-muted/70">{new Date(p.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Smart Lifecycle Info Box */}
      <div className="mt-10 bg-kootam-surface rounded-3xl p-6 text-center">
        <p className="text-xs text-kootam-muted leading-relaxed">
          <strong className="text-white block mb-2 uppercase tracking-wider">Data Lifecycle Policy</strong> 
          Your account and data will be securely retained until one year after your graduation ({currentUser.gradYear + 1}). During your "Bridge Year" as an alumni, you can participate as a Mentor or Judge.
        </p>
      </div>
    </div>
  );
}
