import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Loader2, CheckCircle2, User, Users, ArrowRight, KeyRound } from 'lucide-react';
import { Event } from '../types';
import QRPass from './QRPass';

interface RegistrationModalProps {
  onClose: () => void;
  event: Event;
}

type Step = 'gate' | 'solo_form' | 'team_options' | 'create_team' | 'join_team' | 'success';

export default function RegistrationModal({ onClose, event }: RegistrationModalProps) {
  const [step, setStep] = useState<Step>(event.teamSize && event.teamSize !== 'Solo' ? 'gate' : 'solo_form');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    gender: '',
    criteriaMet: false,
    teamName: '',
    teamCode: ''
  });

  const [generatedCode, setGeneratedCode] = useState('');

  const handleSubmitSolo = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setStep('success');
      setTimeout(() => onClose(), 2000);
    }, 1500);
  };

  const handleCreateTeam = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setGeneratedCode(Math.random().toString(36).substring(2, 8).toUpperCase());
      setStep('success');
    }, 1500);
  };

  const handleJoinTeam = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setStep('success');
      setTimeout(() => onClose(), 2000);
    }, 1500);
  };

  if (step === 'success') {
    return (
      <QRPass 
        event={event} 
        onClose={onClose} 
        teamCode={generatedCode || formData.teamCode} 
        teamName={formData.teamName} 
      />
    );
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md"
      />
      
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 20 }}
        className="relative w-full max-w-md bg-kootam-surface rounded-3xl shadow-2xl overflow-hidden"
      >
        <div className="flex items-center justify-between p-6 pb-2">
          <h2 className="text-xl font-display font-bold text-white">
            {step === 'gate' && 'Registration Type'}
            {step === 'solo_form' && 'Solo Registration'}
            {step === 'team_options' && 'Team Registration'}
            {step === 'create_team' && 'Create a Team'}
            {step === 'join_team' && 'Join a Team'}
            {step === 'success' && 'Success'}
          </h2>
          <button 
            onClick={onClose}
            className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <AnimatePresence mode="wait">
          {step === 'gate' && (
            <motion.div
              key="gate"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="p-6 space-y-4"
            >
              <button
                onClick={() => setStep('solo_form')}
                className="w-full bg-kootam-bg p-6 rounded-2xl flex items-center justify-between group hover:ring-2 hover:ring-kootam-action transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-kootam-surface flex items-center justify-center group-hover:bg-kootam-action/20 group-hover:text-kootam-action transition-colors">
                    <User size={24} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-lg font-bold text-white">Register Solo</h3>
                    <p className="text-sm text-kootam-muted">Participate individually</p>
                  </div>
                </div>
                <ArrowRight className="text-kootam-muted group-hover:text-kootam-action transition-colors" />
              </button>

              <button
                onClick={() => setStep('team_options')}
                className="w-full bg-kootam-bg p-6 rounded-2xl flex items-center justify-between group hover:ring-2 hover:ring-kootam-action transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-kootam-surface flex items-center justify-center group-hover:bg-kootam-action/20 group-hover:text-kootam-action transition-colors">
                    <Users size={24} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-lg font-bold text-white">Register as Team</h3>
                    <p className="text-sm text-kootam-muted">Create or join a team</p>
                  </div>
                </div>
                <ArrowRight className="text-kootam-muted group-hover:text-kootam-action transition-colors" />
              </button>
            </motion.div>
          )}

          {step === 'team_options' && (
            <motion.div
              key="team_options"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="p-6 space-y-4"
            >
              <button
                onClick={() => setStep('create_team')}
                className="w-full bg-kootam-bg p-6 rounded-2xl flex items-center justify-between group hover:ring-2 hover:ring-kootam-action transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-kootam-surface flex items-center justify-center group-hover:bg-kootam-action/20 group-hover:text-kootam-action transition-colors">
                    <Users size={24} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-lg font-bold text-white">Create a Team</h3>
                    <p className="text-sm text-kootam-muted">Generate a code to invite others</p>
                  </div>
                </div>
                <ArrowRight className="text-kootam-muted group-hover:text-kootam-action transition-colors" />
              </button>

              <button
                onClick={() => setStep('join_team')}
                className="w-full bg-kootam-bg p-6 rounded-2xl flex items-center justify-between group hover:ring-2 hover:ring-kootam-action transition-all"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-kootam-surface flex items-center justify-center group-hover:bg-kootam-action/20 group-hover:text-kootam-action transition-colors">
                    <KeyRound size={24} />
                  </div>
                  <div className="text-left">
                    <h3 className="text-lg font-bold text-white">Join a Team</h3>
                    <p className="text-sm text-kootam-muted">Enter a 6-digit team code</p>
                  </div>
                </div>
                <ArrowRight className="text-kootam-muted group-hover:text-kootam-action transition-colors" />
              </button>
            </motion.div>
          )}

          {step === 'solo_form' && (
            <motion.form 
              key="solo_form"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onSubmit={handleSubmitSolo} 
              className="p-6 space-y-6"
            >
              <div>
                <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Full Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.fullName}
                  onChange={e => setFormData({...formData, fullName: e.target.value})}
                  className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                  placeholder="John Doe"
                />
              </div>
              
              <div>
                <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Email Address</label>
                <input 
                  type="email" 
                  required
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                  className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                  placeholder="john@example.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-bold text-kootam-muted mb-3 uppercase tracking-wider">Gender</label>
                <div className="flex gap-4">
                  {['Male', 'Female', 'Other'].map(gender => (
                    <label key={gender} className="flex items-center gap-3 cursor-pointer group">
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${formData.gender === gender ? 'border-kootam-action' : 'border-kootam-muted group-hover:border-white/50'}`}>
                        {formData.gender === gender && <div className="w-2.5 h-2.5 rounded-full bg-kootam-action" />}
                      </div>
                      <input 
                        type="radio" 
                        name="gender" 
                        value={gender}
                        required
                        checked={formData.gender === gender}
                        onChange={e => setFormData({...formData, gender: e.target.value})}
                        className="hidden"
                      />
                      <span className={`text-sm font-medium transition-colors ${formData.gender === gender ? 'text-white' : 'text-kootam-muted group-hover:text-white/80'}`}>{gender}</span>
                    </label>
                  ))}
                </div>
              </div>
              
              <div className="pt-2">
                <label className="flex items-start gap-4 cursor-pointer group">
                  <div className={`mt-0.5 w-5 h-5 rounded border-2 flex items-center justify-center transition-colors shrink-0 ${formData.criteriaMet ? 'border-kootam-action bg-kootam-action' : 'border-kootam-muted group-hover:border-white/50'}`}>
                    {formData.criteriaMet && <CheckCircle2 size={14} className="text-white" />}
                  </div>
                  <input 
                    type="checkbox" 
                    required
                    checked={formData.criteriaMet}
                    onChange={e => setFormData({...formData, criteriaMet: e.target.checked})}
                    className="hidden"
                  />
                  <span className={`text-sm leading-relaxed transition-colors ${formData.criteriaMet ? 'text-white' : 'text-kootam-muted group-hover:text-white/80'}`}>
                    I confirm that I meet the eligibility criteria for this opportunity and agree to the terms of participation.
                  </span>
                </label>
              </div>
              
              <div className="pt-6">
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 bg-kootam-action hover:bg-red-600 text-white font-bold py-4 px-6 rounded-full transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Submit Registration'
                  )}
                </button>
              </div>
            </motion.form>
          )}

          {step === 'create_team' && (
            <motion.form 
              key="create_team"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onSubmit={handleCreateTeam} 
              className="p-6 space-y-6"
            >
              <div>
                <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Team Name</label>
                <input 
                  type="text" 
                  required
                  value={formData.teamName}
                  onChange={e => setFormData({...formData, teamName: e.target.value})}
                  className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                  placeholder="e.g. The Innovators"
                />
              </div>
              
              <div className="pt-6">
                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 bg-kootam-action hover:bg-red-600 text-white font-bold py-4 px-6 rounded-full transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      Generating Code...
                    </>
                  ) : (
                    'Create Team & Get Code'
                  )}
                </button>
              </div>
            </motion.form>
          )}

          {step === 'join_team' && (
            <motion.form 
              key="join_team"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              onSubmit={handleJoinTeam} 
              className="p-6 space-y-6"
            >
              <div>
                <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">6-Digit Team Code</label>
                <input 
                  type="text" 
                  required
                  maxLength={6}
                  value={formData.teamCode}
                  onChange={e => setFormData({...formData, teamCode: e.target.value.toUpperCase()})}
                  className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all text-center text-2xl tracking-[0.5em] font-mono uppercase"
                  placeholder="XXXXXX"
                />
              </div>
              
              <div className="pt-6">
                <button 
                  type="submit" 
                  disabled={isSubmitting || formData.teamCode.length !== 6}
                  className="w-full flex items-center justify-center gap-2 bg-kootam-action hover:bg-red-600 text-white font-bold py-4 px-6 rounded-full transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    'Join Team'
                  )}
                </button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
