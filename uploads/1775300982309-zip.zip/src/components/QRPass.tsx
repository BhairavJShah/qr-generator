import React from 'react';
import { motion } from 'motion/react';
import { X, QrCode, Calendar, MapPin, Clock, Download } from 'lucide-react';
import { Event } from '../types';

interface QRPassProps {
  event: Event;
  onClose: () => void;
  teamCode?: string;
  teamName?: string;
}

export default function QRPass({ event, onClose, teamCode, teamName }: QRPassProps) {
  const dateObj = new Date(event.date);
  const formattedDate = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const formattedTime = dateObj.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-md"
      />
      
      <motion.div
        initial={{ scale: 0.95, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.95, opacity: 0, y: 20 }}
        className="relative w-full max-w-sm bg-kootam-surface rounded-[2rem] shadow-2xl overflow-hidden"
      >
        <div className="absolute top-4 right-4 z-10">
          <button 
            onClick={onClose}
            className="p-2 bg-black/20 backdrop-blur-md text-white hover:bg-black/40 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <div className="relative h-32 w-full bg-kootam-bg">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-full object-cover opacity-50"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-kootam-surface to-transparent" />
        </div>

        <div className="px-6 pb-8 pt-0 relative z-10 -mt-12 flex flex-col items-center text-center">
          <div className="w-24 h-24 bg-white rounded-2xl p-2 shadow-xl mb-4 flex items-center justify-center">
            {/* Placeholder for actual QR code image */}
            <QrCode size={80} className="text-black" />
          </div>

          <h2 className="text-2xl font-display font-bold text-white mb-1">{event.title}</h2>
          <p className="text-kootam-muted font-medium mb-6">{event.organization || event.hostCollege}</p>

          <div className="w-full bg-kootam-bg rounded-2xl p-4 space-y-3 mb-6 text-left">
            <div className="flex items-center text-sm">
              <Calendar size={16} className="text-kootam-action mr-3 shrink-0" />
              <span className="text-white font-medium">{formattedDate}</span>
            </div>
            <div className="flex items-center text-sm">
              <Clock size={16} className="text-kootam-action mr-3 shrink-0" />
              <span className="text-white font-medium">{formattedTime}</span>
            </div>
            <div className="flex items-center text-sm">
              <MapPin size={16} className="text-kootam-action mr-3 shrink-0" />
              <span className="text-white font-medium truncate">{event.location}</span>
            </div>
          </div>

          {teamCode && (
            <div className="w-full bg-kootam-action/10 border border-kootam-action/20 rounded-2xl p-4 mb-6">
              <p className="text-xs font-bold text-kootam-action uppercase tracking-wider mb-1">Team Code</p>
              <p className="text-2xl font-mono tracking-[0.2em] text-white font-bold">{teamCode}</p>
              {teamName && <p className="text-sm text-kootam-muted mt-1">{teamName}</p>}
            </div>
          )}

          <button className="w-full flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-bold py-4 px-6 rounded-full transition-all active:scale-[0.98]">
            <Download size={20} />
            Save to Photos
          </button>
        </div>
      </motion.div>
    </div>
  );
}
