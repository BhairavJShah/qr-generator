import { useState, useMemo } from 'react';
import { Search, UserPlus, MessageSquare, Clock, Filter, X, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { mockNetworkUsers } from '../data/mock';

interface NetworkProps {
  onOpenChat: (user: any) => void;
}

export default function Network({ onOpenChat }: NetworkProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [users, setUsers] = useState(mockNetworkUsers);
  const [showFilters, setShowFilters] = useState(false);
  
  const [filters, setFilters] = useState({
    year: [] as string[],
    gender: [] as string[],
    department: [] as string[],
    college: [] as string[],
    skills: [] as string[]
  });

  const handleConnect = (id: string) => {
    setUsers(users.map(u => u.id === id ? { ...u, connectionStatus: 'pending' } : u));
  };

  const toggleFilter = (category: keyof typeof filters, value: string) => {
    setFilters(prev => ({
      ...prev,
      [category]: prev[category].includes(value) 
        ? prev[category].filter(v => v !== value)
        : [...prev[category], value]
    }));
  };

  const clearFilters = () => {
    setFilters({ year: [], gender: [], department: [], college: [], skills: [] });
  };

  const filteredUsers = users.filter(u => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.college.toLowerCase().includes(searchQuery.toLowerCase()) || 
      u.techStack.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesYear = filters.year.length === 0 || filters.year.includes(u.yearOfStudy);
    const matchesGender = filters.gender.length === 0 || filters.gender.includes(u.gender);
    const matchesDept = filters.department.length === 0 || filters.department.includes(u.department);
    const matchesCollege = filters.college.length === 0 || filters.college.includes(u.college);
    const matchesSkills = filters.skills.length === 0 || filters.skills.some(s => u.techStack.includes(s));

    return matchesSearch && matchesYear && matchesGender && matchesDept && matchesCollege && matchesSkills;
  });

  const activeFilterCount = (Object.values(filters) as string[][]).reduce((acc: number, curr: string[]) => acc + curr.length, 0);

  // Extract unique values for filter options
  const availableColleges = useMemo(() => Array.from(new Set(users.map(u => u.college))), [users]);
  const availableDepartments = useMemo(() => Array.from(new Set(users.map(u => u.department))), [users]);
  const availableSkills = useMemo(() => Array.from(new Set(users.flatMap(u => u.techStack))), [users]);
  const availableGenders = ['Male', 'Female', 'Non-binary', 'Other'];
  const availableYears = ['1st Year', '2nd Year', '3rd Year', '4th Year'];

  const FilterSection = ({ title, category, options }: { title: string, category: keyof typeof filters, options: string[] }) => (
    <div>
      <h4 className="font-bold text-sm text-white mb-4 uppercase tracking-wider">{title}</h4>
      <div className="flex flex-wrap gap-2">
        {options.map(opt => {
          const isSelected = filters[category].includes(opt);
          return (
            <button
              key={opt}
              onClick={() => toggleFilter(category, opt)}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all flex items-center gap-2 ${
                isSelected 
                  ? 'bg-kootam-action text-white' 
                  : 'bg-kootam-bg text-kootam-muted hover:text-white hover:bg-white/5'
              }`}
            >
              {isSelected && <Check size={14} strokeWidth={3} />}
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="p-4 pb-24 h-full relative">
      <div className="flex gap-3 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-kootam-muted" size={20} />
          <input
            type="text"
            placeholder="Search students, skills..."
            className="w-full pl-12 pr-4 py-4 bg-kootam-surface rounded-full focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <button 
          onClick={() => setShowFilters(true)}
          className="relative p-4 bg-kootam-surface rounded-full text-kootam-muted hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-kootam-action"
        >
          <Filter size={20} />
          {activeFilterCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-kootam-action text-white text-[10px] font-bold flex items-center justify-center rounded-full">
              {activeFilterCount}
            </span>
          )}
        </button>
      </div>
      
      <h2 className="text-2xl font-display font-bold text-white mb-6">Discover Network</h2>
      
      <div className="space-y-4">
        {filteredUsers.map(user => (
          <div key={user.id} className="bg-kootam-surface p-5 rounded-3xl flex items-center gap-4 transition-colors">
            <img src={user.avatarUrl} alt={user.name} className="w-16 h-16 rounded-full object-cover bg-kootam-bg p-1" referrerPolicy="no-referrer" />
            <div className="flex-1">
              <h3 className="text-lg font-display font-bold text-white leading-tight mb-1">{user.name}</h3>
              <p className="text-xs text-kootam-muted font-medium mb-2">{user.college} • {user.department} • {user.yearOfStudy}</p>
              <div className="flex flex-wrap gap-1.5">
                {user.techStack.slice(0, 3).map(tech => (
                  <span key={tech} className="text-[10px] bg-kootam-bg text-kootam-muted font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
            <div>
              {user.connectionStatus === 'connected' && (
                <button 
                  onClick={() => onOpenChat(user)} 
                  className="p-3 bg-kootam-accent/10 text-kootam-accent rounded-full hover:bg-kootam-accent/20 transition-colors"
                  aria-label="Message"
                >
                  <MessageSquare size={20} />
                </button>
              )}
              {user.connectionStatus === 'pending' && (
                <button 
                  disabled 
                  className="p-3 bg-kootam-bg text-kootam-muted rounded-full"
                  aria-label="Pending Connection"
                >
                  <Clock size={20} />
                </button>
              )}
              {user.connectionStatus === 'none' && (
                <button 
                  onClick={() => handleConnect(user.id)} 
                  className="p-3 bg-kootam-action text-white rounded-full hover:bg-red-600 transition-colors"
                  aria-label="Connect"
                >
                  <UserPlus size={20} />
                </button>
              )}
            </div>
          </div>
        ))}
        {filteredUsers.length === 0 && (
          <div className="text-center py-16 text-kootam-muted">
            <div className="bg-kootam-surface w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Search size={32} className="text-kootam-muted/50" />
            </div>
            <p className="font-display font-bold text-xl text-white mb-2">No students found</p>
            <p className="text-sm">Try adjusting your search or filters.</p>
            {activeFilterCount > 0 && (
              <button 
                onClick={clearFilters}
                className="mt-6 text-sm text-kootam-action font-bold uppercase tracking-wider hover:text-red-400 transition-colors"
              >
                Clear all filters
              </button>
            )}
          </div>
        )}
      </div>

      {/* Filter Modal */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center md:max-w-md md:mx-auto"
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-kootam-surface w-full max-h-[85vh] rounded-t-[2rem] sm:rounded-[2rem] flex flex-col overflow-hidden shadow-2xl"
            >
              <div className="p-6 pb-4 flex justify-between items-center bg-kootam-surface sticky top-0 z-10">
                <h3 className="font-display font-bold text-2xl text-white">Filters</h3>
                <button 
                  onClick={() => setShowFilters(false)} 
                  className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-full transition-colors"
                >
                  <X size={24}/>
                </button>
              </div>
              
              <div className="p-6 overflow-y-auto flex-1 space-y-10">
                <FilterSection title="Year of Study" category="year" options={availableYears} />
                <FilterSection title="Gender" category="gender" options={availableGenders} />
                <FilterSection title="Department" category="department" options={availableDepartments} />
                <FilterSection title="College" category="college" options={availableColleges} />
                <FilterSection title="Skills" category="skills" options={availableSkills} />
              </div>
              
              <div className="p-6 pt-4 flex gap-4 bg-kootam-surface sticky bottom-0 z-10">
                <button 
                  onClick={clearFilters} 
                  className="flex-1 py-4 bg-kootam-bg text-white rounded-full font-bold hover:bg-white/10 transition-colors"
                >
                  Clear All
                </button>
                <button 
                  onClick={() => setShowFilters(false)} 
                  className="flex-1 py-4 bg-kootam-action text-white rounded-full font-bold hover:bg-red-600 transition-colors"
                >
                  Show {filteredUsers.length} Results
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
