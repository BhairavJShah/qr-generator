import { motion } from 'motion/react';
import { Home, Users } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'home' | 'portfolio' | 'network';
  onChange: (tab: 'home' | 'portfolio' | 'network') => void;
}

export default function BottomNav({ activeTab, onChange }: BottomNavProps) {
  const tabs = [
    { id: 'home', icon: Home, label: 'Explore' },
    { id: 'network', icon: Users, label: 'Connect' },
  ] as const;

  return (
    <div className="fixed bottom-4 left-6 right-6 bg-[rgba(255,255,255,0.04)] backdrop-blur-md rounded-full py-3 px-6 flex justify-around items-center z-50 shadow-2xl md:max-w-md md:mx-auto transition-colors duration-200">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex flex-col items-center p-2 w-20 relative transition-colors ${
              isActive ? 'text-kootam-action' : 'text-kootam-muted hover:text-white'
            }`}
          >
            <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
            <span className="text-[10px] font-medium mt-1">{tab.label}</span>
          </button>
        );
      })}
    </div>
  );
}
