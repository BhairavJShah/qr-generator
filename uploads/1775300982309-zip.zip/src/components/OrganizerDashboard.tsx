import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Upload, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, Plus, Calendar, MapPin, Users, Monitor, Trophy, QrCode, TrendingUp, Download, Eye, Edit3, Trash2 } from 'lucide-react';
import QRScanner from './QRScanner';

export default function OrganizerDashboard() {
  const [activeTab, setActiveTab] = useState<'create' | 'manage'>('manage');
  const [showScanner, setShowScanner] = useState(false);

  // Mock data for organizer's events
  const myEvents = [
    {
      id: 'e1',
      title: 'HackTheFuture 2026',
      status: 'Active',
      registrations: 142,
      capacity: 200,
      views: 850,
      date: 'Apr 15, 2026',
      revenue: '₹45,000'
    },
    {
      id: 'e2',
      title: 'Design Thinking Workshop',
      status: 'Draft',
      registrations: 0,
      capacity: 50,
      views: 12,
      date: 'May 10, 2026',
      revenue: '₹0'
    }
  ];

  return (
    <div className="pb-24 pt-6 px-4">
      <div className="flex bg-kootam-surface rounded-full p-1 mb-8">
        <button
          onClick={() => setActiveTab('manage')}
          className={`flex-1 py-3 rounded-full text-sm font-bold transition-all ${
            activeTab === 'manage' ? 'bg-kootam-action text-white' : 'text-kootam-muted hover:text-white'
          }`}
        >
          Manage Events
        </button>
        <button
          onClick={() => setActiveTab('create')}
          className={`flex-1 py-3 rounded-full text-sm font-bold transition-all ${
            activeTab === 'create' ? 'bg-kootam-action text-white' : 'text-kootam-muted hover:text-white'
          }`}
        >
          Host Opportunity
        </button>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'create' ? (
          <motion.div
            key="create"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            <div className="bg-kootam-surface rounded-3xl p-6">
              <h2 className="text-2xl font-display font-bold text-white mb-6">Host an Event</h2>
              
              <form className="space-y-6">
                {/* Logo Upload */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-3 uppercase tracking-wider">Organization Logo</label>
                  <div className="w-full h-32 bg-kootam-bg rounded-2xl border-2 border-dashed border-kootam-muted/30 flex flex-col items-center justify-center text-kootam-muted hover:border-kootam-action hover:text-kootam-action transition-colors cursor-pointer group">
                    <Upload size={24} className="mb-2 group-hover:-translate-y-1 transition-transform" />
                    <span className="text-sm font-medium">Click to upload logo</span>
                  </div>
                </div>

                {/* Event Type */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Event Type</label>
                  <select defaultValue="" className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white appearance-none">
                    <option value="" disabled>Select Event Type</option>
                    <option value="Hackathon">Hackathon</option>
                    <option value="Quiz">Quiz</option>
                    <option value="Conference">Conference</option>
                    <option value="Cultural Event">Cultural Event</option>
                    <option value="College Festival">College Festival</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                {/* Title & Org */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Opportunity Title</label>
                    <input 
                      type="text" 
                      className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                      placeholder="e.g. National Hackathon 2026"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Organization Name</label>
                    <input 
                      type="text" 
                      className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                      placeholder="e.g. Tech Club, IIT Madras"
                    />
                  </div>
                </div>

                {/* Rich Text Description */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Opportunity Description</label>
                  <div className="bg-kootam-bg rounded-2xl overflow-hidden focus-within:ring-2 focus-within:ring-kootam-action transition-all">
                    <div className="flex items-center gap-1 p-2 border-b border-white/5 bg-kootam-surface/50">
                      <button type="button" className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-lg transition-colors"><Bold size={16} /></button>
                      <button type="button" className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-lg transition-colors"><Italic size={16} /></button>
                      <button type="button" className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-lg transition-colors"><Underline size={16} /></button>
                      <div className="w-px h-4 bg-white/10 mx-1" />
                      <button type="button" className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-lg transition-colors"><AlignLeft size={16} /></button>
                      <button type="button" className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-lg transition-colors"><AlignCenter size={16} /></button>
                      <button type="button" className="p-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-lg transition-colors"><AlignRight size={16} /></button>
                    </div>
                    <textarea 
                      rows={5}
                      className="w-full px-5 py-4 bg-transparent focus:outline-none text-white placeholder-kootam-muted/50 resize-none"
                      placeholder="Describe the opportunity..."
                    />
                  </div>
                </div>

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Participation Type</label>
                    <select className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white appearance-none">
                      <option>Hackathon</option>
                      <option>Workshop</option>
                      <option>Seminar</option>
                      <option>Cultural</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Team Size</label>
                    <select className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white appearance-none">
                      <option>Solo</option>
                      <option>1-3 Members</option>
                      <option>3-5 Members</option>
                      <option>5+ Members</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Mode</label>
                    <select className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white appearance-none">
                      <option>Offline (In-person)</option>
                      <option>Online</option>
                      <option>Hybrid</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Gender Allowed</label>
                    <select className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white appearance-none">
                      <option>All Genders</option>
                      <option>Male Only</option>
                      <option>Female Only</option>
                    </select>
                  </div>
                </div>

                {/* Registration Criteria */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Who can register</label>
                  <input 
                    type="text" 
                    className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all mb-4"
                    placeholder="e.g. All University Students"
                  />
                  <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Registration Criteria</label>
                  <textarea 
                    rows={3}
                    className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all resize-none"
                    placeholder="e.g. Must be a 3rd or 4th year student..."
                  />
                </div>

                {/* Rewards & Campaign */}
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Rewards & Prizes</label>
                    <input 
                      type="text" 
                      className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                      placeholder="e.g. $5000 Prize Pool"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Campaign Name</label>
                      <input 
                        type="text" 
                        className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                        placeholder="e.g. #VibeWithUs"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Campaign Link</label>
                      <input 
                        type="url" 
                        className="w-full px-5 py-3.5 bg-kootam-bg rounded-2xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
                        placeholder="e.g. https://instagram.com/..."
                      />
                    </div>
                  </div>
                </div>

                {/* Organizer Contacts */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">Organizer Contacts</label>
                  <div className="space-y-3 mb-4">
                    <div className="grid grid-cols-2 gap-3">
                      <input type="text" placeholder="Name" className="w-full px-4 py-3 bg-kootam-bg rounded-xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white text-sm" />
                      <input type="text" placeholder="Role" className="w-full px-4 py-3 bg-kootam-bg rounded-xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white text-sm" />
                      <input type="tel" placeholder="Phone" className="w-full px-4 py-3 bg-kootam-bg rounded-xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white text-sm" />
                      <input type="email" placeholder="Email" className="w-full px-4 py-3 bg-kootam-bg rounded-xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white text-sm" />
                    </div>
                  </div>
                  <button type="button" className="w-full py-3 rounded-xl border-2 border-dashed border-kootam-muted/30 text-kootam-muted font-bold hover:border-kootam-action hover:text-kootam-action transition-colors flex items-center justify-center gap-2 text-sm">
                    <Plus size={16} /> Add Another Contact
                  </button>
                </div>

                {/* FAQs */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-2 uppercase tracking-wider">FAQs</label>
                  <div className="space-y-3 mb-4">
                    <div className="space-y-2 bg-kootam-bg p-4 rounded-2xl">
                      <input type="text" placeholder="Question" className="w-full px-4 py-3 bg-kootam-surface rounded-xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white text-sm" />
                      <textarea placeholder="Answer" rows={2} className="w-full px-4 py-3 bg-kootam-surface rounded-xl focus:outline-none focus:ring-2 focus:ring-kootam-action text-white text-sm resize-none" />
                    </div>
                  </div>
                  <button type="button" className="w-full py-3 rounded-xl border-2 border-dashed border-kootam-muted/30 text-kootam-muted font-bold hover:border-kootam-action hover:text-kootam-action transition-colors flex items-center justify-center gap-2 text-sm">
                    <Plus size={16} /> Add FAQ
                  </button>
                </div>

                {/* Custom Form Fields */}
                <div>
                  <label className="block text-sm font-bold text-kootam-muted mb-3 uppercase tracking-wider">Registration Form Fields</label>
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center justify-between bg-kootam-bg p-4 rounded-2xl">
                      <span className="text-white font-medium">Full Name</span>
                      <span className="text-xs text-kootam-muted font-bold uppercase tracking-wider bg-white/5 px-2 py-1 rounded-md">Required</span>
                    </div>
                    <div className="flex items-center justify-between bg-kootam-bg p-4 rounded-2xl">
                      <span className="text-white font-medium">Email Address</span>
                      <span className="text-xs text-kootam-muted font-bold uppercase tracking-wider bg-white/5 px-2 py-1 rounded-md">Required</span>
                    </div>
                  </div>
                  <button type="button" className="w-full py-4 rounded-2xl border-2 border-dashed border-kootam-muted/30 text-kootam-muted font-bold hover:border-kootam-action hover:text-kootam-action transition-colors flex items-center justify-center gap-2">
                    <Plus size={20} /> Add Custom Field
                  </button>
                </div>

                <div className="pt-6">
                  <button type="button" className="w-full py-4 bg-kootam-action text-white rounded-full font-bold hover:bg-red-600 transition-colors active:scale-[0.98]">
                    Publish Opportunity
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="manage"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="space-y-6"
          >
            {/* Scanner Button */}
            <button 
              onClick={() => setShowScanner(true)}
              className="w-full bg-kootam-action text-white p-6 rounded-3xl flex items-center justify-between group hover:bg-red-600 transition-colors shadow-lg shadow-kootam-action/20"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-md">
                  <QrCode size={24} />
                </div>
                <div className="text-left">
                  <h3 className="text-xl font-display font-bold">QR Check-In Scanner</h3>
                  <p className="text-sm text-white/80">Scan attendee passes</p>
                </div>
              </div>
            </button>

            {/* Event List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-lg font-bold text-white uppercase tracking-wider">Your Events</h3>
                <span className="text-sm text-kootam-muted font-medium">{myEvents.length} Total</span>
              </div>

              {myEvents.map((event) => (
                <div key={event.id} className="bg-kootam-surface rounded-3xl p-6">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-md ${
                          event.status === 'Active' ? 'bg-kootam-accent/20 text-kootam-accent' : 'bg-kootam-muted/20 text-kootam-muted'
                        }`}>
                          {event.status}
                        </span>
                        <span className="text-xs text-kootam-muted font-medium flex items-center gap-1">
                          <Calendar size={12} /> {event.date}
                        </span>
                      </div>
                      <h4 className="text-xl font-display font-bold text-white">{event.title}</h4>
                    </div>
                    <button className="p-2 text-kootam-muted hover:text-white bg-kootam-bg rounded-full transition-colors">
                      <Edit3 size={18} />
                    </button>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    <div className="bg-kootam-bg p-4 rounded-2xl">
                      <div className="flex items-center gap-2 text-kootam-muted mb-1">
                        <Users size={14} />
                        <span className="text-xs font-bold uppercase tracking-wider">Registrations</span>
                      </div>
                      <div className="flex items-end gap-2">
                        <span className="text-2xl font-display font-bold text-white">{event.registrations}</span>
                        <span className="text-sm text-kootam-muted mb-1">/ {event.capacity}</span>
                      </div>
                      <div className="w-full bg-white/5 h-1.5 rounded-full mt-3 overflow-hidden">
                        <div 
                          className="bg-kootam-action h-full rounded-full" 
                          style={{ width: `${(event.registrations / event.capacity) * 100}%` }}
                        />
                      </div>
                    </div>
                    
                    <div className="bg-kootam-bg p-4 rounded-2xl">
                      <div className="flex items-center gap-2 text-kootam-muted mb-1">
                        <Eye size={14} />
                        <span className="text-xs font-bold uppercase tracking-wider">Page Views</span>
                      </div>
                      <div className="flex items-end gap-2">
                        <span className="text-2xl font-display font-bold text-white">{event.views}</span>
                      </div>
                      <div className="flex items-center gap-1 text-kootam-accent text-xs font-bold mt-2">
                        <TrendingUp size={12} /> +12% this week
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button className="flex-1 bg-white/5 hover:bg-white/10 text-white text-sm font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2">
                      <Download size={16} /> Export Data
                    </button>
                    <button className="p-3 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-xl transition-colors">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {showScanner && <QRScanner onClose={() => setShowScanner(false)} />}
    </div>
  );
}
