import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, Bookmark, Settings, Sun, Moon, HelpCircle, Shield } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface MainMenuProps {
  onNavigate?: (tab: string) => void;
}

export default function MainMenu({ onNavigate }: MainMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNavigation = (tab: string) => {
    if (onNavigate) {
      onNavigate(tab);
    }
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 -ml-2 relative rounded-full hover:bg-white/10 text-white transition-colors focus:outline-none"
      >
        <Menu size={24} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute left-0 mt-2 w-64 bg-kootam-surface rounded-2xl shadow-2xl overflow-hidden z-50"
          >
            <div className="py-2">
              <button 
                onClick={() => handleNavigation('organizer')}
                className="w-full text-left px-4 py-3 text-sm text-kootam-accent font-bold hover:bg-white/5 flex items-center gap-3 transition-colors"
              >
                <Shield size={18} />
                Organizer Dashboard
              </button>

              <div className="h-px bg-white/5 my-1 mx-4" />

              <button className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/5 flex items-center gap-3 transition-colors">
                <Bookmark size={18} className="text-kootam-muted" />
                Saved Events
              </button>
              
              <button className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/5 flex items-center gap-3 transition-colors">
                <Settings size={18} className="text-kootam-muted" />
                Settings
              </button>

              <button 
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/5 flex items-center justify-between transition-colors"
              >
                <div className="flex items-center gap-3">
                  {theme === 'dark' ? (
                    <Sun size={18} className="text-kootam-muted" />
                  ) : (
                    <Moon size={18} className="text-kootam-muted" />
                  )}
                  Appearance
                </div>
                <span className="text-xs text-kootam-muted capitalize">{theme}</span>
              </button>

              <button className="w-full text-left px-4 py-3 text-sm text-white hover:bg-white/5 flex items-center gap-3 transition-colors">
                <HelpCircle size={18} className="text-kootam-muted" />
                Help & Support
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
