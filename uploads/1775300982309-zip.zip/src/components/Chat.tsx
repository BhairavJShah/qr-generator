import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Send } from 'lucide-react';

interface ChatProps {
  user: any;
  onBack: () => void;
}

export default function Chat({ user, onBack }: ChatProps) {
  const [messages, setMessages] = useState([
    { 
      id: '1', 
      sender: user.id, 
      text: `Hey! I saw we're both interested in ${user.techStack[0]}. Want to collaborate on a project?`, 
      time: '10:00 AM' 
    }
  ]);
  const [newMessage, setNewMessage] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    setMessages([
      ...messages, 
      { 
        id: Date.now().toString(), 
        sender: 'me', 
        text: newMessage, 
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
      }
    ]);
    setNewMessage('');
  };

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[70] bg-kootam-bg md:max-w-md md:mx-auto flex flex-col shadow-2xl"
    >
      <header className="bg-kootam-surface/80 backdrop-blur-md px-4 pt-safe-6 pb-4 flex items-center gap-4 z-10">
        <button 
          onClick={onBack} 
          className="p-2 -ml-2 rounded-full hover:bg-white/10 text-kootam-muted hover:text-white transition-colors focus:outline-none"
        >
          <ArrowLeft size={24} />
        </button>
        <img 
          src={user.avatarUrl} 
          alt={user.name} 
          className="w-12 h-12 rounded-full object-cover bg-kootam-bg p-0.5" 
          referrerPolicy="no-referrer"
        />
        <div>
          <h2 className="font-display font-bold text-lg text-white leading-tight">{user.name}</h2>
          <p className="text-xs text-kootam-muted font-medium">{user.college}</p>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-3xl px-5 py-3 shadow-sm ${
              msg.sender === 'me' 
                ? 'bg-kootam-action text-white rounded-br-sm' 
                : 'bg-kootam-surface text-white rounded-bl-sm'
            }`}>
              <p className="text-sm leading-relaxed">{msg.text}</p>
              <p className={`text-[10px] mt-2 font-medium text-right ${msg.sender === 'me' ? 'text-white/70' : 'text-kootam-muted'}`}>
                {msg.time}
              </p>
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSend} className="p-4 bg-kootam-surface pb-safe transition-colors">
        <div className="flex items-center gap-3">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-kootam-bg rounded-full px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-kootam-action text-white placeholder-kootam-muted/50 transition-all"
          />
          <button 
            type="submit" 
            disabled={!newMessage.trim()} 
            className="p-4 bg-kootam-action text-white rounded-full hover:bg-red-600 disabled:opacity-50 disabled:hover:bg-kootam-action transition-all focus:outline-none focus:ring-2 focus:ring-kootam-action focus:ring-offset-2 focus:ring-offset-kootam-surface active:scale-[0.95]"
          >
            <Send size={20} className="ml-1 -mt-0.5" />
          </button>
        </div>
      </form>
    </motion.div>
  );
}
