import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Bell, UserPlus, Calendar, Info, Check } from 'lucide-react';
import { Notification } from '../types';

interface Props {
  notifications: Notification[];
  onUpdateNotifications: (notifications: Notification[]) => void;
  onClose: () => void;
}

export default function NotificationsPanel({ notifications, onUpdateNotifications, onClose }: Props) {
  const handleAccept = (id: string) => {
    onUpdateNotifications(notifications.map(n => n.id === id ? { ...n, read: true, message: 'Connection request accepted.' } : n));
  };

  const handleDecline = (id: string) => {
    onUpdateNotifications(notifications.filter(n => n.id !== id));
  };

  const markAllAsRead = () => {
    onUpdateNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const getIcon = (type?: string) => {
    switch (type) {
      case 'connection_request':
        return <UserPlus size={20} className="text-blue-400" />;
      case 'event_update':
        return <Calendar size={20} className="text-orange-400" />;
      default:
        return <Info size={20} className="text-kootam-accent" />;
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 bg-kootam-bg z-[70] flex flex-col md:max-w-md md:mx-auto md:relative md:h-full md:shadow-2xl transition-colors duration-200"
    >
      <div className="bg-kootam-surface/80 backdrop-blur-md px-6 pt-safe-6 pb-4 flex items-center justify-between z-10 transition-colors duration-200">
        <h2 className="text-2xl font-display font-bold text-white flex items-center gap-3">
          <Bell size={24} className="text-kootam-action" />
          Notifications
          {unreadCount > 0 && (
            <span className="bg-kootam-action text-white text-[10px] font-bold px-2.5 py-1 rounded-full">
              {unreadCount}
            </span>
          )}
        </h2>
        <div className="flex items-center gap-3">
          {unreadCount > 0 && (
            <button onClick={markAllAsRead} className="text-xs font-bold text-kootam-muted hover:text-white uppercase tracking-wider transition-colors">
              Mark all read
            </button>
          )}
          <button onClick={onClose} className="p-2 -mr-2 text-kootam-muted hover:text-white hover:bg-white/10 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-kootam-bg transition-colors duration-200">
        {notifications.length === 0 ? (
          <div className="text-center text-kootam-muted mt-16 flex flex-col items-center">
            <div className="w-20 h-20 bg-kootam-surface rounded-full flex items-center justify-center mb-6">
              <Check size={32} className="text-kootam-muted/50" />
            </div>
            <p className="font-display font-bold text-xl text-white mb-2">You're all caught up!</p>
            <p className="text-sm">No new notifications</p>
          </div>
        ) : (
          notifications.map(notif => (
            <div key={notif.id} className={`p-5 rounded-3xl ${notif.read ? 'bg-kootam-surface' : 'bg-kootam-action/10 border border-kootam-action/20'} transition-colors duration-200 flex gap-4`}>
              <div className="mt-1 flex-shrink-0">
                {notif.senderAvatar ? (
                  <img src={notif.senderAvatar} alt={notif.senderName} className="w-12 h-12 rounded-full object-cover bg-kootam-bg p-0.5" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-kootam-bg flex items-center justify-center">
                    {getIcon(notif.type)}
                  </div>
                )}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                  <h3 className={`font-display font-bold text-base ${notif.read ? 'text-white' : 'text-white'}`}>
                    {notif.title}
                  </h3>
                  <span className="text-[10px] font-medium text-kootam-muted whitespace-nowrap ml-2 mt-1">
                    {new Date(notif.timestamp).toLocaleDateString()}
                  </span>
                </div>
                <p className="text-sm text-kootam-muted leading-relaxed mb-3">
                  {notif.message}
                </p>
                
                {notif.type === 'connection_request' && !notif.read && notif.message.includes('wants to connect') && (
                  <div className="flex gap-3 mt-4">
                    <button 
                      onClick={() => handleAccept(notif.id)}
                      className="flex-1 bg-kootam-action hover:bg-red-600 text-white py-2.5 px-4 rounded-full text-sm font-bold transition-colors active:scale-[0.98]"
                    >
                      Accept
                    </button>
                    <button 
                      onClick={() => handleDecline(notif.id)}
                      className="flex-1 bg-kootam-bg hover:bg-white/10 text-white py-2.5 px-4 rounded-full text-sm font-bold transition-colors active:scale-[0.98]"
                    >
                      Decline
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </motion.div>
  );
}
