import React, { useState, useMemo } from 'react';
import { Search, Filter, ChevronDown, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import EventCard from './EventCard';
import { Event } from '../types';

interface HomeProps {
  events: Event[];
  onEventClick: (event: Event) => void;
}

export default function Home({ events, onEventClick }: HomeProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [modeFilter, setModeFilter] = useState<string>('');
  const [typeFilter, setTypeFilter] = useState<string>('');
  const [teamSizeFilter, setTeamSizeFilter] = useState<string>('');
  const [yearFilter, setYearFilter] = useState<string>('');
  const [showFilters, setShowFilters] = useState(false);
  const [visibleCount, setVisibleCount] = useState(5);

  const filteredEvents = useMemo(() => {
    return events.filter(event => {
      const matchesSearch = 
        event.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (event.organization || event.hostCollege).toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesMode = !modeFilter || event.mode === modeFilter;
      const matchesType = !typeFilter || event.eventType === typeFilter;
      const matchesTeamSize = !teamSizeFilter || event.teamSize === teamSizeFilter;
      const matchesYear = !yearFilter || (event.eligibleYears && event.eligibleYears.includes(yearFilter));

      return matchesSearch && matchesMode && matchesType && matchesTeamSize && matchesYear;
    });
  }, [events, searchQuery, modeFilter, typeFilter, teamSizeFilter, yearFilter]);

  const visibleEvents = filteredEvents.slice(0, visibleCount);
  const hasMore = visibleCount < filteredEvents.length;

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 5);
  };

  const activeFilterCount = [modeFilter, typeFilter, teamSizeFilter, yearFilter].filter(Boolean).length;

  return (
    <div className="p-6 relative h-full flex flex-col">
      <div className="mb-6 space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-kootam-muted" size={20} />
          <input
            type="text"
            placeholder="Search by title or organization..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#0E0E0E] rounded-full py-4 pl-12 pr-4 text-sm focus:outline-none text-white transition-all placeholder:text-kootam-muted"
          />
        </div>
        
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-display font-bold text-white">Opportunities</h2>
          <button 
            onClick={() => setShowFilters(true)}
            className={`flex items-center gap-2 text-sm font-bold px-4 py-2 rounded-full transition-colors ${
              activeFilterCount > 0 
                ? 'bg-kootam-action text-white' 
                : 'bg-kootam-surface text-white hover:bg-white/10'
            }`}
          >
            <Filter size={16} />
            Filters
            {activeFilterCount > 0 && (
              <span className="bg-white text-kootam-action text-[10px] w-5 h-5 rounded-full flex items-center justify-center ml-1">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>
      </div>

      <div className="space-y-4 flex-1">
        {visibleEvents.length > 0 ? (
          visibleEvents.map(event => (
            <EventCard 
              key={event.id} 
              event={event} 
              onClick={onEventClick} 
            />
          ))
        ) : (
          <div className="text-center py-12 text-kootam-muted">
            No opportunities match your filters.
          </div>
        )}
      </div>

      {hasMore && (
        <div className="mt-8 flex justify-center">
          <button 
            onClick={handleLoadMore}
            className="bg-kootam-surface text-white font-bold py-3 px-8 rounded-full hover:bg-white/10 transition-colors"
          >
            Load More
          </button>
        </div>
      )}

      {/* Glassmorphism Bottom Sheet Modal for Filters */}
      <AnimatePresence>
        {showFilters && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFilters(false)}
              className="fixed inset-0 bg-black/60 z-40"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 bg-[rgba(28,28,34,0.85)] backdrop-blur-xl z-50 rounded-t-3xl p-6 md:max-w-md md:mx-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-display font-bold text-white">Filters</h3>
                <button onClick={() => setShowFilters(false)} className="p-2 bg-white/10 rounded-full text-white hover:bg-white/20">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-kootam-muted uppercase tracking-wider mb-3">Mode</label>
                  <div className="flex flex-wrap gap-2">
                    {['Online', 'Offline'].map(mode => (
                      <button
                        key={mode}
                        onClick={() => setModeFilter(modeFilter === mode ? '' : mode)}
                        className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${
                          modeFilter === mode ? 'bg-kootam-action text-white' : 'bg-white/5 text-white hover:bg-white/10'
                        }`}
                      >
                        {mode}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-kootam-muted uppercase tracking-wider mb-3">Type</label>
                  <div className="flex flex-wrap gap-2">
                    {['Hackathon', 'Quiz', 'Conference', 'Cultural Event', 'College Festival', 'Other'].map(type => (
                      <button
                        key={type}
                        onClick={() => setTypeFilter(typeFilter === type ? '' : type)}
                        className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${
                          typeFilter === type ? 'bg-kootam-action text-white' : 'bg-white/5 text-white hover:bg-white/10'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-kootam-muted uppercase tracking-wider mb-3">Team Size</label>
                  <div className="flex flex-wrap gap-2">
                    {['Individual', '1-3 members', '1-4 members'].map(size => (
                      <button
                        key={size}
                        onClick={() => setTeamSizeFilter(teamSizeFilter === size ? '' : size)}
                        className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${
                          teamSizeFilter === size ? 'bg-kootam-action text-white' : 'bg-white/5 text-white hover:bg-white/10'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-kootam-muted uppercase tracking-wider mb-3">Eligible Year</label>
                  <div className="flex flex-wrap gap-2">
                    {['1st Year', '2nd Year', '3rd Year', '4th Year'].map(year => (
                      <button
                        key={year}
                        onClick={() => setYearFilter(yearFilter === year ? '' : year)}
                        className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${
                          yearFilter === year ? 'bg-kootam-action text-white' : 'bg-white/5 text-white hover:bg-white/10'
                        }`}
                      >
                        {year}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-8 flex gap-3">
                <button 
                  onClick={() => { setModeFilter(''); setTypeFilter(''); setTeamSizeFilter(''); setYearFilter(''); }}
                  className="flex-1 py-4 rounded-full font-bold text-white bg-white/5 hover:bg-white/10 transition-colors"
                >
                  Clear All
                </button>
                <button 
                  onClick={() => setShowFilters(false)}
                  className="flex-1 py-4 rounded-full font-bold text-white bg-kootam-action hover:bg-red-700 transition-colors shadow-lg shadow-kootam-action/20"
                >
                  Apply Filters
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
