import React from 'react';
import { Event } from '../types';
import { MapPin, Calendar, Clock, Users, Monitor, Trophy } from 'lucide-react';
import { motion } from 'motion/react';

interface EventCardProps {
  key?: React.Key;
  event: Event;
  onClick: (event: Event) => void;
}

export default function EventCard({ event, onClick }: EventCardProps) {
  const dateObj = new Date(event.date);
  const formattedDate = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const formattedTime = dateObj.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

  const now = new Date();
  const timeDiff = dateObj.getTime() - now.getTime();
  const daysLeft = Math.ceil(timeDiff / (1000 * 3600 * 24));
  const isUpcoming = daysLeft > 0;

  return (
    <motion.div
      whileHover={{ scale: 0.98 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => onClick(event)}
      className={`bg-kootam-surface rounded-3xl overflow-hidden cursor-pointer mb-6 transition-colors duration-200 ${
        event.isExpired ? 'opacity-75 grayscale-[0.5]' : ''
      }`}
    >
      <div className="relative h-48 w-full">
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-kootam-surface to-transparent opacity-80" />
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {event.eventType && (
            <span className="bg-kootam-accent/90 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 uppercase tracking-wider">
              {event.eventType}
            </span>
          )}
          {event.participationType && (
            <span className="bg-white/10 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 uppercase tracking-wider">
              <Trophy size={12} className="text-kootam-accent" /> {event.participationType}
            </span>
          )}
        </div>
        <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
          {isUpcoming && !event.isExpired && (
            <span className="bg-kootam-action/90 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 uppercase tracking-wider">
              <Calendar size={12} /> {daysLeft} {daysLeft === 1 ? 'Day' : 'Days'} Left
            </span>
          )}
          {event.isExpired && (
            <span className="bg-red-500/90 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1.5 rounded-full flex items-center gap-1.5 uppercase tracking-wider">
              <Clock size={12} /> Expiring Soon
            </span>
          )}
        </div>
      </div>
      <div className="p-5 pt-0 relative z-10 -mt-8">
        <div className="flex items-start gap-4 mb-4">
          {event.logoUrl ? (
            <img src={event.logoUrl} alt={event.organization || event.hostCollege} className="w-14 h-14 rounded-2xl object-cover bg-kootam-bg p-1" referrerPolicy="no-referrer" />
          ) : (
            <div className="w-14 h-14 rounded-2xl bg-kootam-bg flex items-center justify-center text-kootam-muted text-xs font-bold border-4 border-kootam-surface">
              LOGO
            </div>
          )}
          <div className="pt-2">
            <h3 className="text-xl font-display font-bold text-white leading-tight mb-1">{event.title}</h3>
            <p className="text-sm text-kootam-muted font-medium">{event.organization || event.hostCollege}</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4 mb-4">
          {event.mode && (
            <div className="flex items-center text-kootam-muted text-xs font-bold uppercase tracking-wider">
              <Monitor size={14} className="mr-1.5 text-kootam-accent" />
              <span>{event.mode}</span>
            </div>
          )}
          {event.teamSize && (
            <div className="flex items-center text-kootam-muted text-xs font-bold uppercase tracking-wider">
              <Users size={14} className="mr-1.5 text-kootam-accent" />
              <span>{event.teamSize}</span>
            </div>
          )}
        </div>

        <div className="flex items-center text-kootam-muted text-sm mb-2">
          <Calendar size={16} className="mr-2 text-kootam-action" />
          <span className="font-medium">{formattedDate} • {formattedTime}</span>
        </div>
        <div className="flex items-center text-kootam-muted text-sm mb-4">
          <MapPin size={16} className="mr-2 text-kootam-action" />
          <span className="truncate font-medium">{event.location}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {event.tags.map(tag => (
            <span key={tag} className="bg-white/5 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 rounded-full">
              {tag}
            </span>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
