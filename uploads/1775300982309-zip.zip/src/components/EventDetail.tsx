import { useState } from 'react';
import { Event } from '../types';
import { ChevronLeft, MapPin, Calendar, Users, Code, Clock, Trophy, Phone, Mail, Instagram, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { currentUser } from '../data/mock';
import RegistrationModal from './RegistrationModal';

interface EventDetailProps {
  event: Event;
  onBack: () => void;
}

export default function EventDetail({ event, onBack }: EventDetailProps) {
  const [activeTab, setActiveTab] = useState<'about' | 'faq'>('about');
  const [isRegistering, setIsRegistering] = useState(false);
  const isHost = event.hostId === currentUser.id;

  const dateObj = new Date(event.date);
  const formattedDate = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  const formattedTime = dateObj.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 bg-kootam-bg z-50 overflow-y-auto md:max-w-md md:mx-auto md:relative md:h-full md:shadow-2xl transition-colors duration-200"
    >
      {/* Header Image & Back Button */}
      <div className="relative h-72 w-full">
        <img src={event.imageUrl} alt={event.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        <div className="absolute inset-0 bg-gradient-to-t from-kootam-bg via-kootam-bg/40 to-transparent" />
        <button
          onClick={onBack}
          className="absolute top-safe-4 left-4 bg-[rgba(255,255,255,0.04)] backdrop-blur-md p-2 rounded-full text-white hover:bg-white/10 transition-colors mt-4"
        >
          <ChevronLeft size={24} />
        </button>
        <div className="absolute bottom-6 left-6 right-6">
          <div className="flex flex-wrap gap-2 mb-3">
            <span className="bg-kootam-action text-white text-[10px] font-bold px-3 py-1 rounded-full inline-block uppercase tracking-wider">
              {event.hostCollege}
            </span>
            {event.eventType && (
              <span className="bg-kootam-accent/90 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1 rounded-full inline-block uppercase tracking-wider">
                {event.eventType}
              </span>
            )}
          </div>
          <h1 className="text-3xl font-display font-bold text-white leading-tight">{event.title}</h1>
        </div>
      </div>

      {/* Content */}
      <div className="bg-kootam-bg min-h-screen relative px-6 pt-2 pb-32 transition-colors duration-200">
        {/* Tabs */}
        <div className="flex gap-6 mb-8 overflow-x-auto hide-scrollbar">
          {(['about', 'faq'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-2 text-sm font-semibold capitalize relative whitespace-nowrap transition-colors ${
                activeTab === tab ? 'text-white' : 'text-kootam-muted hover:text-white/80'
              }`}
            >
              {tab === 'about' && 'Information'}
              {tab === 'faq' && 'FAQ'}
              {activeTab === tab && (
                <motion.div
                  layoutId="eventTabIndicator"
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-kootam-action rounded-full"
                />
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'about' && (
              <div className="space-y-8">
                <div className="flex items-start gap-4 text-kootam-muted">
                  <div className="bg-kootam-surface p-3 rounded-2xl">
                    <Calendar className="text-kootam-accent" size={24} />
                  </div>
                  <div className="pt-1">
                    <p className="font-bold text-white text-lg">{formattedDate}</p>
                    <p className="text-sm">{formattedTime}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4 text-kootam-muted">
                  <div className="bg-kootam-surface p-3 rounded-2xl">
                    <MapPin className="text-kootam-accent" size={24} />
                  </div>
                  <div className="pt-1">
                    <p className="font-bold text-white text-lg">{event.location}</p>
                    <p className="text-sm">View on map</p>
                  </div>
                </div>
                
                <div className="bg-kootam-surface rounded-3xl p-6 space-y-4">
                  <h4 className="font-display font-bold text-white text-lg">Eligibility & Criteria</h4>
                  {event.whoCanRegister && (
                    <div className="flex justify-between text-sm">
                      <span className="text-kootam-muted">Who can register:</span>
                      <span className="font-bold text-white text-right">{event.whoCanRegister}</span>
                    </div>
                  )}
                  {event.eligibleYears && event.eligibleYears.length > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-kootam-muted">Eligible Years:</span>
                      <span className="font-bold text-white text-right">{event.eligibleYears.join(', ')}</span>
                    </div>
                  )}
                  {event.gender && (
                    <div className="flex justify-between text-sm">
                      <span className="text-kootam-muted">Allowed Gender:</span>
                      <span className="font-bold text-white text-right">{event.gender}</span>
                    </div>
                  )}
                  {event.registrationCriteria && (
                    <div className="flex flex-col gap-2 text-sm pt-4 mt-2 border-t border-white/5">
                      <span className="text-kootam-muted">Registration Criteria:</span>
                      <span className="font-medium text-white leading-relaxed">{event.registrationCriteria}</span>
                    </div>
                  )}
                </div>

                {event.rewards && (
                  <div className="bg-kootam-surface rounded-3xl p-6 flex items-start gap-4">
                    <div className="bg-kootam-accent/20 p-3 rounded-2xl">
                      <Trophy className="text-kootam-accent" size={24} />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-white text-lg mb-1">Rewards & Prizes</h4>
                      <p className="text-sm text-kootam-muted leading-relaxed">{event.rewards}</p>
                    </div>
                  </div>
                )}

                {event.campaignLink && (
                  <a 
                    href={event.campaignLink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-6 flex items-center justify-between hover:opacity-90 transition-opacity"
                  >
                    <div className="flex items-center gap-4">
                      <div className="bg-white/20 p-3 rounded-2xl">
                        {event.campaignLink.includes('instagram.com') ? <Instagram className="text-white" size={24} /> : <ExternalLink className="text-white" size={24} />}
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-white text-lg mb-1">Campaign</h4>
                        <p className="text-sm text-white/80 font-medium">{event.campaignName || 'View Campaign'}</p>
                      </div>
                    </div>
                    <ChevronLeft className="text-white rotate-180" size={20} />
                  </a>
                )}

                {event.subEvents && event.subEvents.length > 0 && (
                  <div>
                    <h3 className="text-2xl font-display font-bold text-white mb-4">Events List</h3>
                    <div className="space-y-4">
                      {event.subEvents.map((subEvent) => (
                        <div key={subEvent.id} className="bg-kootam-surface rounded-3xl p-5 flex gap-4">
                          <img src={subEvent.imageUrl} alt={subEvent.title} className="w-20 h-20 rounded-2xl object-cover" referrerPolicy="no-referrer" />
                          <div className="flex-1">
                            <h4 className="font-bold text-white text-lg leading-tight mb-1">{subEvent.title}</h4>
                            <p className="text-xs text-kootam-accent font-bold uppercase tracking-wider mb-2">{subEvent.eventType}</p>
                            <div className="flex items-center text-kootam-muted text-xs mb-1">
                              <Calendar size={12} className="mr-1.5" />
                              {new Date(subEvent.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </div>
                            {subEvent.rewards && (
                              <div className="flex items-center text-kootam-muted text-xs">
                                <Trophy size={12} className="mr-1.5 text-yellow-500" />
                                {subEvent.rewards}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <h3 className="text-2xl font-display font-bold text-white mb-4">About Event</h3>
                  <div 
                    className="text-kootam-muted leading-relaxed prose prose-invert max-w-none prose-p:mb-4"
                    dangerouslySetInnerHTML={{ __html: event.description }}
                  />
                </div>

                {event.photos && event.photos.length > 0 && (
                  <div>
                    <h3 className="text-2xl font-display font-bold text-white mb-4">Gallery</h3>
                    <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-4">
                      {event.photos.map((photo, index) => (
                        <img 
                          key={index} 
                          src={photo} 
                          alt={`Gallery ${index + 1}`} 
                          className="w-64 h-40 object-cover rounded-3xl flex-shrink-0"
                          referrerPolicy="no-referrer"
                        />
                      ))}
                    </div>
                  </div>
                )}

                {event.organizerContacts && event.organizerContacts.length > 0 && (
                  <div>
                    <h3 className="text-2xl font-display font-bold text-white mb-4">Organizers</h3>
                    <div className="space-y-4">
                      {event.organizerContacts.map((contact, index) => (
                        <div key={index} className="bg-kootam-surface rounded-3xl p-5 flex items-center justify-between">
                          <div>
                            <h4 className="font-bold text-white text-lg">{contact.name}</h4>
                            {contact.role && <p className="text-sm text-kootam-muted">{contact.role}</p>}
                          </div>
                          <div className="flex gap-3">
                            {contact.phone && (
                              <a href={`tel:${contact.phone}`} className="bg-white/5 p-3 rounded-2xl hover:bg-white/10 transition-colors">
                                <Phone size={20} className="text-kootam-action" />
                              </a>
                            )}
                            {contact.email && (
                              <a href={`mailto:${contact.email}`} className="bg-white/5 p-3 rounded-2xl hover:bg-white/10 transition-colors">
                                <Mail size={20} className="text-kootam-action" />
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {event.isExpired && (
                  <div className="bg-kootam-action/10 p-5 rounded-3xl">
                    <h4 className="text-kootam-action font-display font-bold text-lg mb-2">Automated Cleanup Notice</h4>
                    <p className="text-white/80 text-sm leading-relaxed">This event has concluded and is in its 48-hour retention window. It will be permanently deleted from the database soon.</p>
                  </div>
                )}

                {!isHost && (
                  <button 
                    onClick={() => {
                      if (event.registrationLink) {
                        window.open(event.registrationLink, '_blank');
                      } else {
                        setIsRegistering(true);
                      }
                    }}
                    className="w-full bg-kootam-action text-white font-bold py-4 rounded-full hover:bg-red-700 active:scale-95 transition-all shadow-lg shadow-kootam-action/20"
                  >
                    Register Now
                  </button>
                )}
              </div>
            )}

            {activeTab === 'faq' && (
              <div className="space-y-4">
                {event.faqs && event.faqs.length > 0 ? (
                  event.faqs.map((faq, index) => (
                    <div key={index} className="bg-kootam-surface p-6 rounded-3xl">
                      <h3 className="font-display font-bold text-white mb-2">{faq.question}</h3>
                      <p className="text-sm text-kootam-muted leading-relaxed">{faq.answer}</p>
                    </div>
                  ))
                ) : (
                  <div className="bg-kootam-surface p-6 rounded-3xl">
                    <h3 className="font-display font-bold text-white mb-2">Frequently Asked Questions</h3>
                    <p className="text-sm text-kootam-muted">No FAQs have been added for this event yet.</p>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {isRegistering && (
          <RegistrationModal event={event} onClose={() => setIsRegistering(false)} />
        )}
      </AnimatePresence>
    </motion.div>
  );
}
