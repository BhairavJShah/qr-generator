import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, QrCode, CheckCircle2, XCircle, Camera } from 'lucide-react';

interface QRScannerProps {
  onClose: () => void;
}

export default function QRScanner({ onClose }: QRScannerProps) {
  const [scanState, setScanState] = useState<'scanning' | 'success' | 'invalid'>('scanning');
  const [scannedData, setScannedData] = useState<any>(null);

  // Simulate scanning process
  useEffect(() => {
    if (scanState === 'scanning') {
      const timer = setTimeout(() => {
        // Randomly succeed or fail for demo purposes
        const isSuccess = Math.random() > 0.3;
        if (isSuccess) {
          setScannedData({
            name: 'Alex Chen',
            ticketType: 'Solo Registration',
            id: 'TKT-8923-XYZ'
          });
          setScanState('success');
        } else {
          setScanState('invalid');
        }
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [scanState]);

  const resetScanner = () => {
    setScanState('scanning');
    setScannedData(null);
  };

  return (
    <div className="fixed inset-0 z-[70] flex flex-col bg-black">
      <div className="flex items-center justify-between p-6 pt-safe-6 pb-4 bg-gradient-to-b from-black/80 to-transparent z-10">
        <h2 className="text-xl font-display font-bold text-white">Scan QR Pass</h2>
        <button 
          onClick={onClose}
          className="p-2 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-md transition-colors"
        >
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {/* Simulated Camera Viewfinder */}
        {scanState === 'scanning' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <div className="absolute inset-0 bg-black/40" />
            <div className="relative w-64 h-64 z-10">
              {/* Viewfinder corners */}
              <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-kootam-action rounded-tl-xl" />
              <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-kootam-action rounded-tr-xl" />
              <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-kootam-action rounded-bl-xl" />
              <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-kootam-action rounded-br-xl" />
              
              {/* Scanning animation line */}
              <motion.div 
                animate={{ y: [0, 256, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="absolute top-0 left-0 right-0 h-0.5 bg-kootam-action shadow-[0_0_15px_rgba(227,27,35,0.8)]"
              />
            </div>
            <div className="absolute bottom-24 text-center z-10">
              <Camera size={32} className="mx-auto text-white/50 mb-4" />
              <p className="text-white font-medium tracking-wide">Position QR code within frame</p>
            </div>
          </motion.div>
        )}

        {/* Success State */}
        {scanState === 'success' && (
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-kootam-surface p-8 rounded-[2rem] max-w-sm w-full mx-4 text-center relative z-20 shadow-2xl"
          >
            <div className="w-20 h-20 bg-kootam-accent/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={40} className="text-kootam-accent" />
            </div>
            <h3 className="text-2xl font-display font-bold text-white mb-2">Valid Pass</h3>
            <p className="text-kootam-accent font-bold uppercase tracking-wider text-sm mb-6">Check-in Successful</p>
            
            <div className="bg-kootam-bg rounded-2xl p-4 text-left space-y-3 mb-8">
              <div>
                <p className="text-xs text-kootam-muted font-bold uppercase tracking-wider">Attendee</p>
                <p className="text-white font-medium text-lg">{scannedData?.name}</p>
              </div>
              <div>
                <p className="text-xs text-kootam-muted font-bold uppercase tracking-wider">Ticket Type</p>
                <p className="text-white font-medium">{scannedData?.ticketType}</p>
              </div>
              <div>
                <p className="text-xs text-kootam-muted font-bold uppercase tracking-wider">Pass ID</p>
                <p className="text-kootam-muted font-mono">{scannedData?.id}</p>
              </div>
            </div>

            <button 
              onClick={resetScanner}
              className="w-full bg-kootam-action text-white font-bold py-4 rounded-full hover:bg-red-600 transition-colors active:scale-[0.98]"
            >
              Scan Next Pass
            </button>
          </motion.div>
        )}

        {/* Invalid State */}
        {scanState === 'invalid' && (
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-kootam-surface p-8 rounded-[2rem] max-w-sm w-full mx-4 text-center relative z-20 shadow-2xl"
          >
            <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <XCircle size={40} className="text-red-500" />
            </div>
            <h3 className="text-2xl font-display font-bold text-white mb-2">Invalid Pass</h3>
            <p className="text-red-500 font-bold uppercase tracking-wider text-sm mb-6">Check-in Failed</p>
            
            <p className="text-kootam-muted mb-8">This QR code is not recognized or has already been used.</p>

            <button 
              onClick={resetScanner}
              className="w-full bg-white/10 text-white font-bold py-4 rounded-full hover:bg-white/20 transition-colors active:scale-[0.98]"
            >
              Try Again
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
